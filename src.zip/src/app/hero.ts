export class Hero{
    id: number;
    nome: string;
}